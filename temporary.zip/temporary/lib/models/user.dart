class Users {
  final String uid;
  Users ({required this.uid });
}